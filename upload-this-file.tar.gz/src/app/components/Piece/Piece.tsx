import React from 'react';
import { Piece as PieceType } from '../../../types/chess';

interface PieceProps {
  piece: PieceType;
}

const Piece: React.FC<PieceProps> = ({ piece }) => {
  const { type, player } = piece;
  const src = `/pieces/${type}-${player}.svg`;

  return (
    <img
      src={src}
      alt={`${player} ${type}`}
      style={{ width: 48, height: 48 }}
      draggable={false}
    />
  );
};

export default Piece;
