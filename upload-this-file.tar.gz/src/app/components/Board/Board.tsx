import React from 'react';
import Square from '../Square/Square';
import { Piece } from '../../../types/chess';
import styles from './Board.module.scss';
import PieceComponent from '../Piece/Piece';

interface BoardProps {
  board: (Piece | null)[][];
  onSquareClick?: (row: number, col: number) => void;
}

const Board: React.FC<BoardProps> = ({ board, onSquareClick }) => {
  const rows = board.length;
  const cols = board[0].length;

  return (
    <div
      className={styles.board}
      style={{
        display: 'grid',
        gridTemplateRows: `repeat(${rows}, 72px)`,
        gridTemplateColumns: `repeat(${cols}, 72px)`,
        gap: 0,
      }}
    >
      {board.flatMap((rowArr, rowIdx) =>
        rowArr.map((piece, colIdx) => {
          const isLight = (rowIdx + colIdx) % 2 === 0;
          return (
            <Square
              key={`${rowIdx}-${colIdx}`}
              isLight={isLight}
              onClick={() => onSquareClick?.(rowIdx, colIdx)}
            >
              {piece && <PieceComponent piece={piece} />}
            </Square>
          );
        })
      )}
    </div>
  );
};

export default Board;
