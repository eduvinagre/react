import React from 'react';
import styles from './ScaleControls.module.scss';

interface ScaleControlsProps {
  x: number;
  y: number;
  onXChange: (val: number) => void;
  onYChange: (val: number) => void;
  onPlay: () => void;
}

const ScaleControls: React.FC<ScaleControlsProps> = ({
  x,
  y,
  onXChange,
  onYChange,
  onPlay,
}) => (
  <div className={styles.scaleControls}>
    <div className={styles.inputGroup}>
      <label className={styles.label}>X</label>
      <input
        className={styles.input}
        type="number"
        min={6}
        max={12}
        value={x}
        onChange={(e) => onXChange(Number(e.target.value))}
      />
    </div>
    <div className={styles.inputGroup}>
      <label className={styles.label}>Y</label>
      <input
        className={styles.input}
        type="number"
        min={6}
        max={12}
        value={y}
        onChange={(e) => onYChange(Number(e.target.value))}
      />
    </div>
    <button className={styles.playButton} onClick={onPlay}>
      Play
    </button>
  </div>
);

export default ScaleControls;
