import React, { useState } from 'react';
import styles from './GameConfig.module.scss';

interface GameConfigProps {
  onStart: (rows: number, cols: number) => void;
}

const GameConfig: React.FC<GameConfigProps> = ({ onStart }) => {
  const [rows, setRows] = useState(8);
  const [cols, setCols] = useState(8);

  return (
    <div className={styles.config}>
      <h2>Choose Board Size</h2>
      <div>
        <label>
          Rows:
          <input
            type="number"
            min={6}
            max={12}
            value={rows}
            onChange={(e) => setRows(Number(e.target.value))}
          />
        </label>
        <label>
          Columns:
          <input
            type="number"
            min={6}
            max={12}
            value={cols}
            onChange={(e) => setCols(Number(e.target.value))}
          />
        </label>
      </div>
      <button onClick={() => onStart(rows, cols)}>Play</button>
    </div>
  );
};

export default GameConfig;
