import React from 'react';
import styles from './Square.module.scss';

interface SquareProps {
  isLight: boolean;
  children?: React.ReactNode;
  onClick?: () => void;
  isActive?: boolean;
}

const Square: React.FC<SquareProps> = ({
  isLight,
  children,
  onClick,
  isActive,
}) => (
  <div
    className={`${styles.square} ${isLight ? styles.light : styles.dark} ${
      isActive ? styles.active : ''
    }`}
    onClick={onClick}
  >
    {children}
  </div>
);

export default Square;
