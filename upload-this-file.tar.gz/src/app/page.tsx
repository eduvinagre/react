'use client';

import React, { useState, useEffect } from 'react';
import GameConfig from '../app/components/GameConfig/GameConfig';
import Board from '../app/components/Board/Board';
import ScaleControls from '../app/components/ScaleControls/ScaleControls';
import { Piece, Player } from '../types/chess';
import { getInitialBoard } from '../utils/board';

export default function HomePage() {
  const [rows, setRows] = useState(6);
  const [cols, setCols] = useState(6);
  const [board, setBoard] = useState(() => getInitialBoard(6, 6));

  useEffect(() => {
    setBoard(getInitialBoard(rows, cols));
  }, [rows, cols]);

  const handlePlay = () => setBoard(getInitialBoard(rows, cols));

  return (
    <div
      style={{
        minHeight: '100vh',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      <Board board={board} />
      <div style={{ marginTop: 20 }}>
        <ScaleControls
          x={cols}
          y={rows}
          onXChange={setCols}
          onYChange={setRows}
          onPlay={handlePlay}
        />
      </div>
    </div>
  );
}
