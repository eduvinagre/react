export type PieceType = 'developer' | 'designer' | 'product-owner';
export type Player = 'white' | 'black';

export interface Piece {
  type: PieceType;
  player: Player;
  row: number;
  col: number;
  captured: boolean;
}

export interface BoardConfig {
  rows: number;
  cols: number;
}

export interface GameState {
  board: (Piece | null)[][];
  currentPlayer: Player;
  winner: Player | null;
  config: BoardConfig;
}
